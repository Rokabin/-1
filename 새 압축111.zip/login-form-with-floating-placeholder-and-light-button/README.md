# Login Form with floating placeholder and light button

A Pen created on CodePen.io. Original URL: [https://codepen.io/soufiane-khalfaoui-hassani/pen/LYpPWda](https://codepen.io/soufiane-khalfaoui-hassani/pen/LYpPWda).

